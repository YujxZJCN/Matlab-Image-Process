function [] = HaarDecoding()
load('huffmanEncodingMatrix.mat');
load('huffmanDict.mat');
M = 512;
N = 512;
P = 3;
haarEncodingMatrix = zeros(M,N,3);

for m = 1:3
    deco = huffmandeco(huffmanEncodingMatrix{m},huffmanDict{m});
    Ide = col2im(deco,[M,N],[M,N],'distinct');
    haarEncodingMatrix(:,:,m) = Ide;
end

figure;
imshow(haarEncodingMatrix);

load('haarEncodingMatrix.mat');

for k = 1:P
    tempMatrix = zeros(M,N);
    tempMatrix(:,:) = haarEncodingMatrix(:,:,k);
    temptempMatrix = tempMatrix;
    j = 2;
    i = 2;
    while(i <= M)
        for ff = 1:i/2
            a = double(temptempMatrix(ff,:));
            b = double(temptempMatrix(i/2+ff,:));
            tempMatrix(2*(ff-1)+1,:) = a+b;
            tempMatrix(2*ff,:) = a-b;
        end
        temptempMatrix = tempMatrix;
        i = i*2;
    end
     
    while(j <= N)
        for ff = 1:j/2
            a = double(temptempMatrix(:,ff));
            b = double(temptempMatrix(:,j/2+ff));
            tempMatrix(:,2*(ff-1)+1) = a+b;
            tempMatrix(:,2*ff) = a-b;
        end
        temptempMatrix = tempMatrix;
        j = j*2;
    end
    
    if k == 1
        haarDecodingMatrix = zeros(M,N,P);
    end
    haarDecodingMatrix(:,:,k) = tempMatrix;
end
figure;
imwrite(uint8(haarDecodingMatrix), 'matrix.jpg');
Iinfo = imfinfo('I.jpg');
iminfo = imfinfo('matrix.jpg');

disp(1-iminfo.FileSize/Iinfo.FileSize);

imshow(uint8(haarDecodingMatrix));
end

