function [] = HaarEncoding() %imageName
I = ImageScale('1.jpg',512,512);
imwrite(uint8(I), 'I.jpg');
figure;
imshow(uint8(I));
[M,N,P] = size(I);

for k = 1:P
    tempMatrix = zeros(M,N);
    tempMatrix(:,:) = I(:,:,k);
    temptempMatrix = tempMatrix;
    o = M;
    j = N;
    while (j > 1)
        for i = 1:(j/2)
            a = double(temptempMatrix(:,2*i-1));
            b = double(temptempMatrix(:,2*i));
            tempMatrix(:,i) = double(a+b)/2;
            tempMatrix(:,j/2+i) = double(a-b)/2;
        end
        temptempMatrix = tempMatrix;
        j = j/2;
    end
    while (o > 1)
        for i = 1:(o/2)
            a = double(temptempMatrix(2*i-1,:));
            b = double(temptempMatrix(2*i,:));
            tempMatrix(i,:) = double(a+b)/2;
            tempMatrix(o/2+i,:) = double(a-b)/2;
        end
        temptempMatrix = tempMatrix;
        o = o/2;
    end
    if k == 1
        haarEncodingMatrix = zeros(M,N,P);
    end
    haarEncodingMatrix(:,:,k) = tempMatrix;
end
figure;
for i = 1:M
    for j = 1:N
        if (abs(haarEncodingMatrix(i,j,1)) < 12)
            haarEncodingMatrix(i,j,1) = 0;
        end
        if (abs(haarEncodingMatrix(i,j,2)) < 12)
            haarEncodingMatrix(i,j,2) = 0;
        end
        if (abs(haarEncodingMatrix(i,j,3)) < 12)
            haarEncodingMatrix(i,j,3) = 0;
        end 
    end
end
imshow(haarEncodingMatrix);

huffmanEncodingMatrix = cell(1,3);
huffmanDict = cell(1,3);
for m = 1:3
    I1 = haarEncodingMatrix(:,:,m);
    I1 = uint8(I1(:));

    P = zeros(1,256);
    for i = 0:255
        P(i+1) = length(find(I1 == i))/(M*N);
    end
    k = 0:255;
    dict = huffmandict(k,P);
    enco = huffmanenco(I1,dict);
    huffmanEncodingMatrix{m} = enco;
    huffmanDict{m} = dict;
end
save huffmanEncodingMatrix huffmanEncodingMatrix;
save huffmanDict huffmanDict;
save haarEncodingMatrix haarEncodingMatrix;
end





function [scaledImage] = ImageScale(imageName, scaleM, scaleN)
I = imread(imageName);
[M,N,P] = size(I);

scaledImage = zeros(ceil(scaleM),ceil(scaleN),P);
scaledImage(:,:,1) = zeros(ceil(scaleM),ceil(scaleN));
scaledImage(:,:,2) = zeros(ceil(scaleM),ceil(scaleN));
scaledImage(:,:,3) = zeros(ceil(scaleM),ceil(scaleN));
R = I(:,:,1);
G = I(:,:,2);
B = I(:,:,3);

for dstx = 1:ceil(scaleM)
    for dsty = 1:ceil(scaleN)
        srcx = ceil(dstx*M/scaleM);
        srcy = ceil(dsty*N/scaleN);
        u = srcx - floor(srcx);
        v = srcy - floor(srcy);
        if srcx < 1
            srcx = 1;
        end
        if srcy < 1
            srcy = 1;
        end
        if srcx > M
            srcx = M;
        end
        if srcy > N
            srcy = N;
        end
        scaledImage(dstx,dsty,1) = R(floor(srcx),floor(srcy))*(1-u)*(1-v)+...
            (1-u)*v*R(floor(srcx),ceil(srcy))+R(ceil(srcx), floor(srcy)) * u * (1-v)+...
            R(ceil(srcx), ceil(srcy)) * u * v;
        scaledImage(dstx,dsty,2) = G(floor(srcx),floor(srcy))*(1-u)*(1-v)+...
            (1-u)*v*G(floor(srcx),ceil(srcy))+G(ceil(srcx), floor(srcy)) * u * (1-v)+...
            G(ceil(srcx), ceil(srcy)) * u * v;
        scaledImage(dstx,dsty,3) = B(floor(srcx),floor(srcy))*(1-u)*(1-v)+...
            (1-u)*v*B(floor(srcx),ceil(srcy))+B(ceil(srcx), floor(srcy)) * u * (1-v)+...
            B(ceil(srcx), ceil(srcy)) * u * v;
    end
end
end








