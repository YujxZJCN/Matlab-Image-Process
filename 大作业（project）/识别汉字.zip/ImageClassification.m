needToProcessImage = imread('1.gif');
needToProcessImage = imbinarize(needToProcessImage,graythresh(needToProcessImage));
figure;
imshow(needToProcessImage);
needToProcessImageMatrix = mat2cell(needToProcessImage,[37 37 37 37 37 37 37 37 37 37],[37 37 37 37 37 37 37 37 37 37]);
needToProcessResult = zeros(10,10);
for l = 1:10
    for m = 1:10
        needToProcessResult(l,m) = sum(needToProcessImageMatrix{l,m},'all');
    end
end
needToProcessResult = reshape(needToProcessResult, 1, 100);
A=sqrt(sum(needToProcessResult.^2));

outputFolder = fullfile('project');
rootFolder = fullfile(outputFolder,'data');

categories = {'��','��','��','��','��','��','��','ɢ','��','ʯ','ˮ','��','��','��','Ω','��','��','��','ѧ','��','��','��','��','��','��','֦','֪','��','��','��'};
imds = imageDatastore(fullfile(rootFolder,categories),'LabelSource','foldernames');

tbl = countEachLabel(imds);
for idx = 1:30
    tblIdx = find(tbl.Label == categories(idx));
    for index = 1:tbl{tblIdx,2}
        i = readimage(imds,find(imds.Labels == categories(idx),1)+index-1);
        i = imbinarize(i,graythresh(i));
        cellMatrix = mat2cell(i,[37 37 37 37 37 37 37 37 37 37],[37 37 37 37 37 37 37 37 37 37]);
        result = zeros(10,10);
        for l = 1:10
            for m = 1:10
                result(l,m) = sum(cellMatrix{l,m},'all');
            end
        end
        result = reshape(result, 1, 100);
        B=sqrt(sum(result.^2));
        C=sum(sum(result.*needToProcessResult));
        cos1=C/(A*B);
        if cos1 >= 0.97
            figure;
            imshow(i);
        end
    end
    if flag == 1
        break;
    end
end
