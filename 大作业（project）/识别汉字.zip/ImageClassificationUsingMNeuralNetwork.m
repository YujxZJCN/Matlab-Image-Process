load W;
load B;

predictImage = imread('1.gif');
predictImage = imbinarize(predictImage,graythresh(predictImage));
predictImageMatrix = mat2cell(predictImage,[37 37 37 37 37 37 37 37 37 37],[37 37 37 37 37 37 37 37 37 37]);
temp = zeros(10,10);
for l = 1:10
    for k = 1:10
        temp(l,k) = sum(predictImageMatrix{l,k},'all');
    end
end
temp = reshape(temp,100,1);
predictX = temp;
 
predictX = predictX/1369;

outputFolder = fullfile('project');
rootFolder = fullfile('data');

categories = {'��','��','��','��','��','��','��','ɢ','��','ʯ','ˮ','��','��','��','Ω','��','��','��','ѧ','��','��','��','��','��','��','֦','֪','��','��','��'};
imds = imageDatastore(fullfile(rootFolder,categories),'LabelSource','foldernames');

tbl = countEachLabel(imds);
rightW = zeros(100,1);
rightB = 0;
for idx = 1:30
    z = (W(:,idx))'*predictX+B(1,idx);
    a = double(1./(1+exp(-z)));
    if a > 0.5
        disp(categories(idx));
        rightW = W(:,idx);
        rightB = B(1,idx);
    end
end

for kk = 1:sum(tbl.Count)
    i = readimage(imds,kk);
    i = imbinarize(i,graythresh(i));
    cellMatrix = mat2cell(i,[37 37 37 37 37 37 37 37 37 37],[37 37 37 37 37 37 37 37 37 37]);
    x = zeros(10,10);
    for l = 1:10
        for k = 1:10
            x(l,k) = sum(cellMatrix{l,k},'all');
        end
    end
    x = reshape(x,100,1);
    x = x/1369;
    z = rightW'*x+rightB;
    a = double(1./(1+exp(-z)));
    if a > 0.5
        figure;
        imshow(i);
    end
end

