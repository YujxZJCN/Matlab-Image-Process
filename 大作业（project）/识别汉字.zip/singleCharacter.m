outputFolder = fullfile('project');
rootFolder = fullfile(outputFolder,'data');

categories = {'��','��','��','��','��','��','��','ɢ','��','ʯ','ˮ','��','��','��','Ω','��','��','��','ѧ','��','��','��','��','��','��','֦','֪','��','��','��'};
imds = imageDatastore(fullfile(rootFolder,categories),'LabelSource','foldernames');

tbl = countEachLabel(imds);

w = zeros(100,1);
b = 0;
trainingRate = 0.01;

tblIdx = find(tbl.Label == categories(29));
x = zeros(100,sum(tbl.Count));
y = zeros(1,sum(tbl.Count));

for mm = 1:sum(tbl.Count)
    needToProcessImage = readimage(imds,mm);
    needToProcessImage = imbinarize(needToProcessImage,graythresh(needToProcessImage));
    needToProcessImageMatrix = mat2cell(needToProcessImage,[37 37 37 37 37 37 37 37 37 37],[37 37 37 37 37 37 37 37 37 37]);
    temp = zeros(10,10);
    if imds.Labels(mm) == categories(29)
        y(1,mm) = 1;
    else
        y(1,mm) = 0;
    end

    for l = 1:10
        for k = 1:10
            temp(l,k) = sum(needToProcessImageMatrix{l,k},'all');
        end
    end
    temp = reshape(temp,1,100);
    x(:,mm) = temp;
end   

x = x/1369;
for hh = 1:100000
    z = w'*x+b;
    a = 1./(1+exp(-z));
    dw = 1/tbl{tblIdx,2}*(x*(a-y)');
    db = 1/tbl{tblIdx,2}*sum(a-y);
    w = w-trainingRate*dw;
    b = b-trainingRate*db;
end

predictImage = imread('1.gif');
predictImage = imbinarize(predictImage,graythresh(predictImage));
predictImageMatrix = mat2cell(predictImage,[37 37 37 37 37 37 37 37 37 37],[37 37 37 37 37 37 37 37 37 37]);
temp = zeros(10,10);
for l = 1:10
    for k = 1:10
        temp(l,k) = sum(predictImageMatrix{l,k},'all');
    end
end
temp = reshape(temp,100,1);
predictX = temp;
 
predictX = predictX/1369;

z = w'*predictX+b;
a = 1./(1+exp(-z));
disp(a);



