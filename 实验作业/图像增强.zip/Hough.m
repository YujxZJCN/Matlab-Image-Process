I = imread('1.jpg');
GI = rgb2gray(I);
bw = edge(GI,'canny');
[H,GI,R] = hough(bw);
f = houghpeaks(H,50,'threshold',ceil(0.2*max(H(:))));
x = GI(f(:,2));
y = R(f(:,1));
lines = houghlines(bw,GI,R,f,'FillGap',20,'MinLength',7);
figure,imshow(I),hold on;
max_len = 0;
xy_long = cell(1,3);
cnt = 1;
lenForAll = cell(1,length(lines));

for k = 1:length(lines)
    xy = [lines(k).point1; lines(k).point2];

    len = norm(lines(k).point1 - lines(k).point2);
    lenForAll{k} = len;
end
lenForAll = cell2mat(lenForAll);
[lenForAll_sort,ind]=sort(lenForAll);
xy_long{1} = [lines(ind(end)).point1; lines(ind(end)).point2];
xy_long{2} = [lines(ind(end-1)).point1; lines(ind(end-1)).point2];
xy_long{3} = [lines(ind(end-2)).point1; lines(ind(end-2)).point2];

for i = 1:3
    toMat = xy_long{i};
    plot(toMat(:,1),toMat(:,2),'LineWidth',2,'Color','cyan');
    plot(toMat(1,1),toMat(1,2),'x','LineWidth',2,'Color','yellow');
    plot(toMat(2,1),toMat(2,2),'x','LineWidth',2,'Color','red');
end
