I = imread('2.jpg');
figure;
subplot(1,2,1);
imshow(I);
subplot(1,2,2);
imshow(I);
BW = im2bw(I, graythresh(I)); 
[B,L] = bwboundaries(BW,'noholes');
hold on;
disp(length(B));
whos B;
maxArea = cell(1,3);
areaForAll = cell(1,length(B));
cnt = 1;
for k = 1:length(B)
    boundary = B{k};
    areaForAll{k} = polyarea(boundary(:,2), boundary(:,1));
end
areaForAll = cell2mat(areaForAll);
[areaForAll_sort,ind]=sort(areaForAll);
for i = 1:3
    boundary = B{ind(end-i+1)};
    plot(boundary(:,2), boundary(:,1), 'b', 'LineWidth', 5);
end
