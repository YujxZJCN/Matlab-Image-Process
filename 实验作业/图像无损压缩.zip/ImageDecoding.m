function [] = ImageDecoding(imageData)
load(imageData,'codingMatrix');
[M,N] = size(codingMatrix);
M = M/3;

codingMatrix = mat2cell(codingMatrix,[M,M,M],N);
codingMatrixR = cell2mat(codingMatrix(1,1));
codingMatrixG = cell2mat(codingMatrix(2,1));
codingMatrixB = cell2mat(codingMatrix(3,1));

decodingMatrixR = zeros(M,N);
decodingMatrixG = zeros(M,N);
decodingMatrixB = zeros(M,N);

for i = 1:M
    for j = 1:N
        if i == 1
            decodingMatrixR(i,j) = codingMatrixR(i,j);
            decodingMatrixG(i,j) = codingMatrixG(i,j);
            decodingMatrixB(i,j) = codingMatrixB(i,j);
        else
            decodingMatrixR(i,j) = decodingMatrixR(i-1,j)+codingMatrixR(i,j);
            decodingMatrixG(i,j) = decodingMatrixG(i-1,j)+codingMatrixG(i,j);
            decodingMatrixB(i,j) = decodingMatrixB(i-1,j)+codingMatrixB(i,j);
        end
    end
end

decodingImageMatrix = zeros(M,N,3);
decodingImageMatrix(:,:,1) = decodingMatrixR;
decodingImageMatrix(:,:,2) = decodingMatrixG;
decodingImageMatrix(:,:,3) = decodingMatrixB;

imshow(uint8(decodingImageMatrix));

end
