function [] = ImageEncoding(imageName)
I = imread(imageName);
[M,N,~] = size(I);

R = I(:,:,1);
G = I(:,:,2);
B = I(:,:,3);

codingMatrixR = zeros(M,N);
codingMatrixG = zeros(M,N);
codingMatrixB = zeros(M,N);

for i = 1:M
    for j = 1:N
        if i == 1
            codingMatrixR(i,j) = R(i,j);
            codingMatrixG(i,j) = G(i,j);
            codingMatrixB(i,j) = B(i,j);
        else
            codingMatrixR(i,j) = double(R(i,j)) - double(R(i-1,j));
            codingMatrixG(i,j) = double(G(i,j)) - double(G(i-1,j));
            codingMatrixB(i,j) = double(B(i,j)) - double(B(i-1,j));
        end
    end
end

codingMatrix = [codingMatrixR;codingMatrixG;codingMatrixB];
afterCodingMatrix = zeros(M,N,3);
afterCodingMatrix(:,:,1) = codingMatrixR;
afterCodingMatrix(:,:,2) = codingMatrixG;
afterCodingMatrix(:,:,3) = codingMatrixB;
imshow(afterCodingMatrix);

save codingmatrix codingMatrix;
end

