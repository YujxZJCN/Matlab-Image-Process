function [] = Process(img)
I = imread(img);
[M,N,~] = size(I);
grayPlot = zeros(M, N);
graySquare = zeros(1,256);
binaryPlot = zeros(M,N);
binarySquare = zeros(1,2);

figure;
subplot(2,3,1);
imshow(I);

R = I(:,:,1);
G = I(:,:,2);
B = I(:,:,3);

grayPlot = R*0.299+G*0.587+B*0.114;
binaryIndex = grayPlot > 128;
binaryPlot(binaryIndex) = 1;

subplot(2,3,2);
imshow(uint8(grayPlot));
subplot(2,3,3);
imshow(binaryPlot);

graySquare = tabulate(grayPlot(:));
binarySquare = tabulate(binaryPlot(:));

subplot(2,3,4);
bar(graySquare(:,end-2),graySquare(:,end-1));
subplot(2,3,5);
bar(binarySquare(:,end-2),binarySquare(:,end-1));

end
