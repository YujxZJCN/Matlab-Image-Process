function [scaledImage] = ImageScale(imageName, scaleM, scaleN)
I = imread(imageName);
[M,N,P] = size(I);

scaledImage = zeros(ceil(scaleM),ceil(scaleN),P);
scaledImage(:,:,1) = zeros(ceil(scaleM),ceil(scaleN));
scaledImage(:,:,2) = zeros(ceil(scaleM),ceil(scaleN));
scaledImage(:,:,3) = zeros(ceil(scaleM),ceil(scaleN));
R = I(:,:,1);
G = I(:,:,2);
B = I(:,:,3);

for dstx = 1:ceil(scaleM)
    for dsty = 1:ceil(scaleN)
        srcx = ceil(dstx*M/scaleM);
        srcy = ceil(dsty*N/scaleN);
        u = srcx - floor(srcx);
        v = srcy - floor(srcy);
        if srcx < 1
            srcx = 1;
        end
        if srcy < 1
            srcy = 1;
        end
        if srcx > M
            srcx = M;
        end
        if srcy > N
            srcy = N;
        end
        scaledImage(dstx,dsty,1) = R(floor(srcx),floor(srcy))*(1-u)*(1-v)+...
            (1-u)*v*R(floor(srcx),ceil(srcy))+R(ceil(srcx), floor(srcy)) * u * (1-v)+...
            R(ceil(srcx), ceil(srcy)) * u * v;
        scaledImage(dstx,dsty,2) = G(floor(srcx),floor(srcy))*(1-u)*(1-v)+...
            (1-u)*v*G(floor(srcx),ceil(srcy))+G(ceil(srcx), floor(srcy)) * u * (1-v)+...
            G(ceil(srcx), ceil(srcy)) * u * v;
        scaledImage(dstx,dsty,3) = B(floor(srcx),floor(srcy))*(1-u)*(1-v)+...
            (1-u)*v*B(floor(srcx),ceil(srcy))+B(ceil(srcx), floor(srcy)) * u * (1-v)+...
            B(ceil(srcx), ceil(srcy)) * u * v;
    end
end

figure;
imshow(I);
figure;
imshow(uint8(scaledImage));
end
