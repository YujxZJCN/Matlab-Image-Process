function [] = LaplacianImageEnhancement() % imageName
I = imread('1.jpg');
% I = rgb2gray(I);
% I = filter2(fspecial('average',15),I)/255;
figure;
subplot(1,3,1);
imshow(I);
[M,N,L] = size(I);
afterProcessImageMatrix = zeros(M,N,L);

for l = 1:L
    currentLayerMatrix = I(:,:,l);

    tempLayerMatrix = zeros(M,N);
    for m = 1:M
        for n = 1:N
            if m == 1 || n==1 || m == M || n == N
                tempLayerMatrix(m,n) = currentLayerMatrix(m,n);
                continue;
            end
            tempLayerMatrix(m,n) = currentLayerMatrix(m-1,n-1)+currentLayerMatrix(m,n-1)+...
                currentLayerMatrix(m+1,n-1)+currentLayerMatrix(m-1,n)+currentLayerMatrix(m+1,n)+...
                currentLayerMatrix(m-1,n+1)+currentLayerMatrix(m,n+1)+currentLayerMatrix(m+1,n+1)-...
                8*currentLayerMatrix(m,n);
            if tempLayerMatrix(m,n) > 255
                tempLayerMatrix(m,n) = 255;
            else if tempLayerMatrix(m,n) < 0 
                    tempLayerMatrix(m,n) = 0;
                end
            end
        end
    end
    afterProcessImageMatrix(:,:,l) = tempLayerMatrix;
end
subplot(1,3,2);
imshow(uint8(afterProcessImageMatrix));
newI = imadd(uint8(afterProcessImageMatrix),I);
subplot(1,3,3);
imshow(newI);
end
